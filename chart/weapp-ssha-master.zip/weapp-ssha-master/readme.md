# 盛世华安-小程序

## 说明
盛世华安-小程序，提供公司新闻资讯、产品服务、宣传视频、联系方式等。

## 访问
 * 微信小程序搜索“**江苏盛世华安**”

 * 扫码访问
 
![](http://iat-net-cn.qiniudn.com/weapp-ssha.jpg)

![](http://iat-net-cn.qiniudn.com/weapp-jlxh.jpg)

## 预览
![](http://iat.net.cn/images/weapp-ssha-1.png)

![](http://iat.net.cn/images/weapp-ssha-2.png)
---


## 安装

    git clone https://github.com/yaoshanliang/weapp-ssha.git
    
    // 静态页面
    git checkout static
    
    // 动态页面
    git checkout api

## 版本
* v1
  * v1.0.0 第一版静态页面
  * v1.0.1 Fixed 弹幕移动至左侧无法消失的bug
  * v1.0.2 删除无用的page文件夹

* v2
  * v2.0.0 第一版api获取数据展示

