
const utils = {
  getCommonStr (route) {
    return '公共模块方法'
  }
}

export default utils
