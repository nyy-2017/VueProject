<template>
  <div>这是project2子模块的Test组件</div>
</template>
